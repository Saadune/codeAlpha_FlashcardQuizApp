let flashcards = [
      { question: "What is the capital of France?", answer: "Paris" },      
      { question: "what is the deadline for submitting this assignment?", answer: "30june" },
      { question: "What is 2 + 2?", answer: "4" },
      { question: "What is the largest planet?", answer: "Jupiter" }
    ];

    let currentIndex = 0;
    let showingAnswer = false;

    function displayCard() {
      const card = flashcards[currentIndex];
      document.getElementById('flashcard-content').textContent = showingAnswer ? card.answer : card.question;
    }

    function toggleAnswer() {
      showingAnswer = !showingAnswer;
      displayCard();
    }

    function nextCard() {
      currentIndex = (currentIndex + 1) % flashcards.length;
      showingAnswer = false;
      displayCard();
    }

    function prevCard() {
      currentIndex = (currentIndex - 1 + flashcards.length) % flashcards.length;
      showingAnswer = false;
      displayCard();
    }

    function addCard() {
      const question = document.getElementById('new-question').value.trim();
      const answer = document.getElementById('new-answer').value.trim();
      if (question && answer) {
        flashcards.push({ question, answer });
        document.getElementById('new-question').value = '';
        document.getElementById('new-answer').value = '';
        currentIndex = flashcards.length - 1;
        showingAnswer = false;
        displayCard();
      }
    }

    function deleteCard() {
      if (flashcards.length > 1) {
        flashcards.splice(currentIndex, 1);
        currentIndex = 0;
        showingAnswer = false;
        displayCard();
      } else {
        alert("Can't delete the last flashcard.");
      }
    }

    // Initialize first card
    displayCard();
  